<?php
require_once dirname(dirname(__DIR__)) . '/admin/auth_check.php';
require_once dirname(dirname(__DIR__)) . '/admin/layout.php';

$uploadDir = UPLOADS_PATH;
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0775, true);
}

// ----------------------------------------------------
// 1. UPLOAD FILE HANDLER
// ----------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['uploaded_files'])) {
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'zip', 'txt', 'mp3', 'mp4'];
    $files = $_FILES['uploaded_files'];
    $count = count($files['name']);
    $uploadedCount = 0;

    for ($i = 0; $i < $count; $i++) {
        if ($files['error'][$i] === UPLOAD_ERR_OK) {
            $originalName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $files['name'][$i]);
            $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

            if (in_array($ext, $allowed)) {
                $targetFile = $uploadDir . '/' . time() . '_' . $originalName;
                if (move_uploaded_file($files['tmp_name'][$i], $targetFile)) {
                    $uploadedCount++;
                }
            }
        }
    }

    if ($uploadedCount > 0) {
        set_flash('success', "Successfully uploaded {$uploadedCount} file(s).");
    } else {
        set_flash('error', "No valid files uploaded. Allowed: " . implode(', ', $allowed));
    }
    redirect('admin_page.php');
}

// ----------------------------------------------------
// 2. DELETE FILE HANDLER
// ----------------------------------------------------
if (isset($_GET['delete'])) {
    $fileToDelete = basename($_GET['delete']);
    $fullPath = $uploadDir . '/' . $fileToDelete;

    if (file_exists($fullPath) && is_file($fullPath)) {
        @unlink($fullPath);
        set_flash('success', "File '{$fileToDelete}' deleted successfully.");
    }
    redirect('admin_page.php');
}

// ----------------------------------------------------
// 3. SCAN UPLOADS DIRECTORY
// ----------------------------------------------------
$allFiles = array_filter(glob($uploadDir . '/*'), 'is_file');
rsort($allFiles); // Show newest uploads first

admin_header('File Manager', 'file_manager');
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2>📁 File Manager & Media Library</h2>
</div>

<!-- Upload Box -->
<div class="panel" style="margin-bottom: 25px;">
    <h3 class="panel-title">📤 Upload New Files & Images</h3>
    <form method="POST" enctype="multipart/form-data" style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
        <input type="file" name="uploaded_files[]" multiple required style="max-width: 380px;">
        <button type="submit" class="btn btn-primary">Upload to Server</button>
    </form>
    <small style="color: #64748b; display: block; margin-top: 8px;">
        Allowed extensions: <code>JPG</code>, <code>PNG</code>, <code>WEBP</code>, <code>GIF</code>, <code>PDF</code>, <code>ZIP</code>, <code>TXT</code>, <code>MP3</code>, <code>MP4</code>.
    </small>
</div>

<!-- Uploaded Media Grid -->
<div class="panel">
    <h3 class="panel-title">Uploaded Media Items (<?php echo count($allFiles); ?>)</h3>

    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px; margin-top: 15px;">
        <?php if (!empty($allFiles)): ?>
            <?php foreach ($allFiles as $filePath): 
                $fileName = basename($filePath);
                $fileUrl  = BASE_URL . '/uploads/' . $fileName;
                $ext      = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                $isImg    = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                $fileSize = round(filesize($filePath) / 1024, 1) . ' KB';
            ?>
                <div style="border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #fff; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
                    
                    <!-- Preview Box -->
                    <div style="height: 140px; background: #f8fafc; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                        <?php if ($isImg): ?>
                            <img src="<?php echo $fileUrl; ?>" alt="" style="width: 100%; height: 100%; object-fit: cover;">
                        <?php else: ?>
                            <div style="font-size: 2.5rem; color: #64748b;">📄</div>
                        <?php endif; ?>
                    </div>

                    <!-- File Details & Action Buttons -->
                    <div style="padding: 12px;">
                        <div style="font-size: 0.85rem; font-weight: 600; color: #1e293b; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?php echo htmlspecialchars($fileName); ?>">
                            <?php echo htmlspecialchars($fileName); ?>
                        </div>
                        <div style="font-size: 0.75rem; color: #64748b; margin-top: 3px;"><?php echo $fileSize; ?> &bull; <code>.<?php echo $ext; ?></code></div>
                        
                        <div style="display: flex; gap: 6px; margin-top: 12px;">
                            <button type="button" class="btn btn-sm btn-primary" style="flex: 1; font-size: 0.75rem;" onclick="navigator.clipboard.writeText('<?php echo $fileUrl; ?>'); alert('Copied to clipboard!\n\n<?php echo $fileUrl; ?>');">
                                📋 Copy URL
                            </button>
                            <a href="admin_page.php?delete=<?php echo urlencode($fileName); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to permanently delete this file?');" style="font-size: 0.75rem;">
                                🗑️
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="grid-column: 1 / -1; padding: 25px; text-align: center; color: #64748b;">
                No files uploaded yet. Choose files above to get started!
            </div>
        <?php endif; ?>
    </div>
</div>

<?php admin_footer(); ?>