<?php
require_once dirname(dirname(__DIR__)) . '/admin/auth_check.php';
require_once dirname(dirname(__DIR__)) . '/admin/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_seo'])) {
    update_setting('seo_default_desc', sanitize($_POST['seo_default_desc'] ?? ''));
    update_setting('seo_default_image', sanitize($_POST['seo_default_image'] ?? ''));
    update_setting('seo_twitter_handle', sanitize($_POST['seo_twitter_handle'] ?? ''));
    update_setting('seo_google_verify', sanitize($_POST['seo_google_verify'] ?? ''));

    // Clear template cache
    $cached = glob(CACHE_PATH . '/*.php');
    if ($cached) array_map('unlink', $cached);

    set_flash('success', 'SEO settings updated successfully.');
    redirect('admin_page.php');
}

admin_header('SEO Settings', 'wardok_seo');
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
    <h2>🔍 Wardok SEO & Sitemap Settings</h2>
</div>

<div style="display: grid; grid-template-columns: 1fr 340px; gap: 25px;">
    <!-- Form Panel -->
    <div class="panel">
        <h3 class="panel-title">Meta & Social Sharing Configuration</h3>
        <form method="POST">
            <div class="form-group">
                <label>Default Meta Description</label>
                <textarea name="seo_default_desc" rows="3" placeholder="A brief summary of your website for Google search results..."><?php echo htmlspecialchars(get_setting('seo_default_desc')); ?></textarea>
                <small style="color:#64748b;">Recommended length: 150–160 characters.</small>
            </div>

            <div class="form-group">
                <label>Default Social Share Image URL</label>
                <input type="url" name="seo_default_image" placeholder="https://yourdomain.com/uploads/banner.jpg" value="<?php echo htmlspecialchars(get_setting('seo_default_image')); ?>">
                <small style="color:#64748b;">Displayed on Facebook, WhatsApp, and Twitter when a post has no thumbnail.</small>
            </div>

            <div class="form-group">
                <label>Twitter / X Username</label>
                <input type="text" name="seo_twitter_handle" placeholder="@yourhandle" value="<?php echo htmlspecialchars(get_setting('seo_twitter_handle')); ?>">
            </div>

            <div class="form-group">
                <label>Google Search Console Verification Tag</label>
                <input type="text" name="seo_google_verify" placeholder="e.g. google1234567890abcdef" value="<?php echo htmlspecialchars(get_setting('seo_google_verify')); ?>">
            </div>

            <button type="submit" name="save_seo" class="btn btn-primary">Save SEO Settings</button>
        </form>
    </div>

    <!-- Live Feeds Panel -->
    <div>
        <div class="panel">
            <h3 class="panel-title">🤖 Live SEO Feeds</h3>
            <ul style="list-style: none; padding: 0;">
                <li style="padding: 12px 0; border-bottom: 1px solid #f1f5f9;">
                    <strong>XML Sitemap</strong>
                    <div style="margin-top: 4px;">
                        <a href="<?php echo BASE_URL; ?>/sitemap.xml" target="_blank" style="color:#0284c7; text-decoration:none; font-size:0.9rem;">
                            🔗 /sitemap.xml
                        </a>
                    </div>
                </li>
                <li style="padding: 12px 0;">
                    <strong>Robots.txt</strong>
                    <div style="margin-top: 4px;">
                        <a href="<?php echo BASE_URL; ?>/robots.txt" target="_blank" style="color:#0284c7; text-decoration:none; font-size:0.9rem;">
                            🔗 /robots.txt
                        </a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>

<?php admin_footer(); ?>