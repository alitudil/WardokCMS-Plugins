<?php

// ----------------------------------------------------
// 1. ADD ADMIN SIDEBAR MENU
// ----------------------------------------------------
add_action('admin_sidebar_menu', function($activePage) {
    $isActive = ($activePage === 'wardok_seo') ? 'active' : '';
    echo '<li class="' . $isActive . '"><a href="' . BASE_URL . '/plugins/wardok-seo/admin_page.php">🔍 SEO Settings</a></li>';
});

// ----------------------------------------------------
// 2. ROUTE DISPATCHER: SITEMAP.XML & ROBOTS.TXT
// ----------------------------------------------------
add_action('route_dispatcher', function($path) {
    $db = DB::getConnection();

    // Route: /sitemap.xml
    if ($path === 'sitemap.xml') {
        header('Content-Type: application/xml; charset=utf-8');
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        // Home
        echo "  <url>\n    <loc>" . BASE_URL . "/</loc>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n";

        // Published Posts
        $posts = $db->query("SELECT slug, updated_at FROM posts WHERE post_type = 'post' AND status = 'published' ORDER BY created_at DESC")->fetchAll();
        foreach ($posts as $p) {
            $lastmod = date('Y-m-d', strtotime($p['updated_at']));
            echo "  <url>\n    <loc>" . BASE_URL . "/post/" . htmlspecialchars($p['slug']) . "</loc>\n    <lastmod>{$lastmod}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>\n";
        }

        // Static Pages
        $pages = $db->query("SELECT slug, updated_at FROM posts WHERE post_type = 'page' AND status = 'published'")->fetchAll();
        foreach ($pages as $pg) {
            $lastmod = date('Y-m-d', strtotime($pg['updated_at']));
            echo "  <url>\n    <loc>" . BASE_URL . "/pages/" . htmlspecialchars($pg['slug']) . "</loc>\n    <lastmod>{$lastmod}</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.6</priority>\n  </url>\n";
        }

        // Categories
        $cats = $db->query("SELECT slug FROM categories")->fetchAll();
        foreach ($cats as $c) {
            echo "  <url>\n    <loc>" . BASE_URL . "/category/" . htmlspecialchars($c['slug']) . "</loc>\n    <changefreq>weekly</changefreq>\n    <priority>0.5</priority>\n  </url>\n";
        }

        echo '</urlset>';
        exit;
    }

    // Route: /robots.txt
    if ($path === 'robots.txt') {
        header('Content-Type: text/plain; charset=utf-8');
        echo "User-agent: *\n";
        echo "Disallow: /admin/\n";
        echo "Disallow: /cache/\n";
        echo "Allow: /\n\n";
        echo "Sitemap: " . BASE_URL . "/sitemap.xml\n";
        exit;
    }
});

// ----------------------------------------------------
// 3. INJECT OPENGRAPH, TWITTER & META TAGS IN <HEAD>
// ----------------------------------------------------
add_filter('frontend_head', function($headContent, $path) {
    $db = DB::getConnection();

    $siteTitle    = get_setting('blog_title', 'My Blog');
    $defaultDesc  = get_setting('seo_default_desc', get_setting('blog_description', ''));
    $defaultImg   = get_setting('seo_default_image', '');
    $twitterUser  = get_setting('seo_twitter_handle', '');
    $googleVerify = get_setting('seo_google_verify', '');

    $pageTitle = $siteTitle;
    $pageDesc  = $defaultDesc;
    $pageUrl   = BASE_URL . '/' . ltrim($path, '/');
    $pageImg   = $defaultImg;
    $type      = 'website';

    // Single Post Metadata
    if (preg_match('#^post/([a-zA-Z0-9_-]+)$#', $path, $matches)) {
        $stmt = $db->prepare("SELECT title, content FROM posts WHERE slug = :s AND post_type = 'post' AND status = 'published'");
        $stmt->execute(['s' => $matches[1]]);
        $post = $stmt->fetch();

        if ($post) {
            $type = 'article';
            $pageTitle = $post['title'] . ' | ' . $siteTitle;
            $pageDesc  = mb_strimwidth(strip_tags($post['content']), 0, 160, '...');
            
            // Check for image inside content
            $firstImg = extract_first_image($post['content']);
            if ($firstImg) $pageImg = $firstImg;
        }
    }

    // Single Page Metadata
    if (preg_match('#^pages/([a-zA-Z0-9_-]+)$#', $path, $matches)) {
        $stmt = $db->prepare("SELECT title, content FROM posts WHERE slug = :s AND post_type = 'page'");
        $stmt->execute(['s' => $matches[1]]);
        $pageData = $stmt->fetch();

        if ($pageData) {
            $pageTitle = $pageData['title'] . ' | ' . $siteTitle;
            $pageDesc  = mb_strimwidth(strip_tags($pageData['content']), 0, 160, '...');
        }
    }

    // Build Output Tags
    $html = "\n    <!-- Wardok SEO Meta Tags -->\n";
    $html .= '    <meta name="description" content="' . htmlspecialchars($pageDesc) . '">' . "\n";
    $html .= '    <link rel="canonical" href="' . htmlspecialchars($pageUrl) . '">' . "\n";

    if ($googleVerify) {
        $html .= '    <meta name="google-site-verification" content="' . htmlspecialchars($googleVerify) . '">' . "\n";
    }

    // OpenGraph
    $html .= '    <meta property="og:type" content="' . $type . '">' . "\n";
    $html .= '    <meta property="og:title" content="' . htmlspecialchars($pageTitle) . '">' . "\n";
    $html .= '    <meta property="og:description" content="' . htmlspecialchars($pageDesc) . '">' . "\n";
    $html .= '    <meta property="og:url" content="' . htmlspecialchars($pageUrl) . '">' . "\n";
    $html .= '    <meta property="og:site_name" content="' . htmlspecialchars($siteTitle) . '">' . "\n";
    if ($pageImg) {
        $html .= '    <meta property="og:image" content="' . htmlspecialchars($pageImg) . '">' . "\n";
    }

    // Twitter Card
    $html .= '    <meta name="twitter:card" content="summary_large_image">' . "\n";
    $html .= '    <meta name="twitter:title" content="' . htmlspecialchars($pageTitle) . '">' . "\n";
    $html .= '    <meta name="twitter:description" content="' . htmlspecialchars($pageDesc) . '">' . "\n";
    if ($twitterUser) {
        $html .= '    <meta name="twitter:site" content="@' . ltrim(htmlspecialchars($twitterUser), '@') . '">' . "\n";
    }
    if ($pageImg) {
        $html .= '    <meta name="twitter:image" content="' . htmlspecialchars($pageImg) . '">' . "\n";
    }

    return $headContent . $html;
});