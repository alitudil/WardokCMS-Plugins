<?php
require_once dirname(dirname(__DIR__)) . '/config.php';

// Auth Guard
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    die(json_encode(['error' => 'Unauthorized']));
}

$action = $_GET['action'] ?? '';

// Helper to configure bulletproof cURL for proxies & Cloudflare
function setup_curl_headers($ch, $apiKey) {
    $headers = [
        'Content-Type: application/json',
        'Accept: application/json, text/event-stream',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ];
    if (!empty($apiKey)) {
        $headers[] = 'Authorization: Bearer ' . trim($apiKey);
    }

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Shared hosting SSL fix
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
}

// ----------------------------------------------------
// 1. FETCH MODELS LIST (/v1/models)
// ----------------------------------------------------
if ($action === 'get_models') {
    header('Content-Type: application/json');

    $input   = json_decode(file_get_contents('php://input'), true);
    $apiBase = rtrim($input['api_base'] ?? get_setting('ai_api_base', 'https://api.openai.com/v1'), '/');
    $apiKey  = $input['api_key'] ?? get_setting('ai_api_key', '');

    $url = $apiBase . '/models';
    $ch = curl_init($url);
    setup_curl_headers($ch, $apiKey);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        $json = json_decode($response, true);
        $models = [];
        if (!empty($json['data']) && is_array($json['data'])) {
            foreach ($json['data'] as $m) {
                if (isset($m['id'])) $models[] = $m['id'];
            }
            sort($models);
        }
        echo json_encode(['success' => true, 'models' => $models]);
    } else {
        echo json_encode([
            'success' => false, 
            'error'   => "HTTP {$httpCode}: " . ($curlError ?: substr($response, 0, 150))
        ]);
    }
    exit;
}

// ----------------------------------------------------
// 2. STREAM CHAT COMPLETION (SSE Stream)
// ----------------------------------------------------
if ($action === 'stream' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $apiBase = rtrim(get_setting('ai_api_base', 'https://api.openai.com/v1'), '/');
    $apiKey  = get_setting('ai_api_key', '');
    $model    = $input['model'] ?? get_setting('ai_selected_model', 'gemini-3.1-preview');
    $messages = $input['messages'] ?? [];

    // Disable output buffering for live streaming
    if (function_exists('apache_setenv')) {
        @apache_setenv('no-gzip', '1');
    }
    @ini_set('zlib.output_compression', '0');
    @ini_set('implicit_flush', '1');
    while (ob_get_level()) ob_end_flush();

    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-transform');
    header('X-Accel-Buffering: no');

    $payload = json_encode([
        'model'       => $model,
        'messages'    => $messages,
        'stream'      => true,
        'temperature' => 0.7
    ]);

    $ch = curl_init($apiBase . '/chat/completions');
    setup_curl_headers($ch, $apiKey);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_TIMEOUT, 120);

    // Forward SSE stream chunk-by-chunk
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) {
        echo $data;
        flush();
        return strlen($data);
    });

    curl_exec($ch);
    curl_close($ch);
    exit;
}