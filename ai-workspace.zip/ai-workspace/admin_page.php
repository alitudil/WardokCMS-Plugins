<?php
require_once dirname(dirname(__DIR__)) . '/admin/auth_check.php';
require_once dirname(dirname(__DIR__)) . '/admin/layout.php';

// Save Settings
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_ai_settings'])) {
    update_setting('ai_api_base', rtrim(sanitize($_POST['ai_api_base'] ?? ''), '/'));
    update_setting('ai_api_key', trim($_POST['ai_api_key'] ?? ''));
    update_setting('ai_selected_model', trim($_POST['ai_selected_model'] ?? ''));
    update_setting('ai_connection_mode', sanitize($_POST['ai_connection_mode'] ?? 'direct'));
    set_flash('success', 'AI settings saved successfully.');
    redirect('admin_page.php');
}

$apiBase        = get_setting('ai_api_base', 'https://gcli.ggchan.dev/v1');
$apiKey         = get_setting('ai_api_key', '');
$selectedModel  = get_setting('ai_selected_model', 'gemini-3.1-preview');
$connectionMode = get_setting('ai_connection_mode', 'direct');

admin_header('AI Workspace', 'ai_workspace');
?>

<style>
.ai-container { display: grid; grid-template-columns: 1fr 340px; gap: 20px; }
@media (max-width: 900px) { .ai-container { grid-template-columns: 1fr; } }

.chat-box { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; height: 530px; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
.chat-messages { flex: 1; padding: 20px; overflow-y: auto; display: flex; flex-direction: column; gap: 15px; }

.msg { max-width: 85%; padding: 12px 16px; border-radius: 10px; font-size: 0.95rem; line-height: 1.5; word-wrap: break-word; }
.msg-user { align-self: flex-end; background: #0284c7; color: #fff; border-bottom-right-radius: 2px; }
.msg-ai { align-self: flex-start; background: #f1f5f9; color: #1e293b; border-bottom-left-radius: 2px; border: 1px solid #e2e8f0; }

/* Reasoning Box Accordion */
.reasoning-box { background: #fff; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px; margin-bottom: 10px; font-size: 0.85rem; color: #64748b; }
.reasoning-box summary { font-weight: 600; cursor: pointer; color: #475569; user-select: none; }
.reasoning-content { margin-top: 8px; white-space: pre-wrap; font-family: monospace; font-size: 0.8rem; max-height: 180px; overflow-y: auto; }

.chat-input-bar { padding: 15px; background: #fff; border-top: 1px solid #e2e8f0; display: flex; gap: 10px; }
.chat-input-bar textarea { flex: 1; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; resize: none; height: 50px; font-family: inherit; font-size: 0.95rem; }

.msg-actions { margin-top: 12px; display: flex; gap: 8px; font-size: 0.8rem; }
.prompt-chips { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; }
.chip { background: #e0f2fe; color: #0369a1; padding: 5px 12px; border-radius: 15px; font-size: 0.78rem; font-weight: 600; cursor: pointer; border: none; }
.chip:hover { background: #bae6fd; }
</style>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2>🤖 AI Content & Brainstorming Workspace</h2>
    <div>
        <span class="badge badge-info">Model: <?php echo htmlspecialchars($selectedModel); ?></span>
    </div>
</div>

<div class="ai-container">
    <!-- Chat Area -->
    <div>
        <div class="prompt-chips">
            <button class="chip" onclick="usePrompt('Give me 5 catchy blog post titles about ')">💡 5 Post Titles</button>
            <button class="chip" onclick="usePrompt('Write a detailed outline for a blog post titled: ')">📑 Article Outline</button>
            <button class="chip" onclick="usePrompt('Write an engaging 3-paragraph introduction about ')">✍️ Introduction</button>
            <button class="chip" onclick="usePrompt('Proofread, optimize, and make this text more engaging:\n')">✨ Polish Text</button>
        </div>

        <div class="chat-box">
            <div class="chat-messages" id="chatMessages">
                <div class="msg msg-ai">
                    👋 <strong>Hello <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</strong><br>
                    AI Workspace is ready. Type a prompt below to brainstorm or write drafts.
                </div>
            </div>

            <div class="chat-input-bar">
                <textarea id="userInput" placeholder="Ask AI something... (Press Enter to send, Shift+Enter for newline)" onkeydown="handleEnter(event)"></textarea>
                <button type="button" id="sendBtn" class="btn btn-primary" onclick="sendMessage()">Send 🚀</button>
            </div>
        </div>
    </div>

    <!-- API Settings Panel -->
    <div>
        <div class="panel">
            <h3 class="panel-title">⚙️ API Configuration</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Connection Mode</label>
                    <select name="ai_connection_mode" id="connectionMode">
                        <option value="direct" <?php echo $connectionMode === 'direct' ? 'selected' : ''; ?>>Direct Browser (SillyTavern Style - Recommended)</option>
                        <option value="proxy" <?php echo $connectionMode === 'proxy' ? 'selected' : ''; ?>>Server Proxy (PHP cURL)</option>
                    </select>
                    <small style="color:#64748b; font-size:0.75rem;">Direct mode bypasses shared hosting firewall restrictions.</small>
                </div>

                <div class="form-group">
                    <label>API Base URL</label>
                    <input type="text" name="ai_api_base" id="apiBase" value="<?php echo htmlspecialchars($apiBase); ?>" placeholder="https://gcli.ggchan.dev/v1" required>
                </div>

                <div class="form-group">
                    <label>API Key (Leave empty if not required)</label>
                    <input type="password" name="ai_api_key" id="apiKey" value="<?php echo htmlspecialchars($apiKey); ?>" placeholder="••••••••••••••••">
                </div>

                <div class="form-group">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                        <label style="margin:0;">Model Name</label>
                        <button type="button" class="btn btn-sm" onclick="fetchModels()" style="background:#e2e8f0; color:#334155; padding:2px 8px; font-size:0.75rem;">🔄 Auto-Detect</button>
                    </div>
                    <input type="text" name="ai_selected_model" id="modelInput" list="modelsList" value="<?php echo htmlspecialchars($selectedModel); ?>" placeholder="gemini-3.1-preview" required>
                    <datalist id="modelsList"></datalist>
                </div>

                <button type="submit" name="save_ai_settings" class="btn btn-primary btn-block">Save API Settings</button>
            </form>
        </div>
    </div>
</div>

<script>
let chatHistory = [];

function usePrompt(text) {
    const input = document.getElementById('userInput');
    input.value = text;
    input.focus();
}

function handleEnter(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}

// ----------------------------------------------------
// 1. LIVE MODEL DISCOVERY (Direct Browser / Proxy)
// ----------------------------------------------------
async function fetchModels() {
    const apiBase = document.getElementById('apiBase').value.trim().replace(/\/+$/, '');
    const apiKey  = document.getElementById('apiKey').value.trim();
    const mode    = document.getElementById('connectionMode').value;
    const datalist = document.getElementById('modelsList');
    const modelInput = document.getElementById('modelInput');

    if (!apiBase) {
        alert('Please enter your API Base URL first.');
        return;
    }

    try {
        let models = [];

        if (mode === 'direct') {
            // Direct Browser Fetch (SillyTavern Style)
            const headers = { 'Accept': 'application/json' };
            if (apiKey) headers['Authorization'] = 'Bearer ' + apiKey;

            const res = await fetch(apiBase + '/models', { method: 'GET', headers: headers });
            if (!res.ok) throw new Error('HTTP ' + res.status + ': ' + (await res.text()).substring(0, 100));
            const data = await res.json();
            if (data.data && Array.isArray(data.data)) {
                models = data.data.map(m => m.id);
            }
        } else {
            // Server Proxy Fetch
            const res = await fetch('api.php?action=get_models', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ api_base: apiBase, api_key: apiKey })
            });
            const data = await res.json();
            if (data.success) models = data.models;
            else throw new Error(data.error);
        }

        if (models.length > 0) {
            datalist.innerHTML = '';
            models.forEach(m => {
                const opt = document.createElement('option');
                opt.value = m;
                datalist.appendChild(opt);
            });
            modelInput.value = models[0];
            alert('Connected successfully! Loaded ' + models.length + ' models.');
        } else {
            alert('No models returned. You can keep typing your model name manually.');
        }
    } catch (err) {
        alert('Notice: ' + err.message + '\n\nYou can still type your model name (e.g. gemini-3.1-preview) manually in the box.');
    }
}

// ----------------------------------------------------
// 2. REAL-TIME STREAMING CHAT (Direct / SillyTavern Style)
// ----------------------------------------------------
async function sendMessage() {
    const input = document.getElementById('userInput');
    const sendBtn = document.getElementById('sendBtn');
    const userText = input.value.trim();

    if (!userText) return;

    appendMessage(userText, 'user');
    chatHistory.push({ role: 'user', content: userText });
    input.value = '';
    sendBtn.disabled = true;
    sendBtn.innerText = 'Thinking...';

    const messagesDiv = document.getElementById('chatMessages');
    const aiBubble = document.createElement('div');
    aiBubble.className = 'msg msg-ai';

    let reasoningText = '';
    let responseText = '';
    let inThinkTag = false;

    aiBubble.innerHTML = `<div class="ai-stream-text">Typing...</div>`;
    messagesDiv.appendChild(aiBubble);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;

    const streamTextContainer = aiBubble.querySelector('.ai-stream-text');

    const apiBase = document.getElementById('apiBase').value.trim().replace(/\/+$/, '');
    const apiKey  = document.getElementById('apiKey').value.trim();
    const model   = document.getElementById('modelInput').value.trim();
    const mode    = document.getElementById('connectionMode').value;

    try {
        let endpointUrl = '';
        let reqHeaders  = { 'Content-Type': 'application/json' };
        let reqBody     = {};

        const messagesPayload = [
            { role: 'system', content: 'You are an expert, engaging blog writing and brainstorming assistant. Provide structured, high-quality responses.' },
            ...chatHistory
        ];

        if (mode === 'direct') {
            // Direct Browser Fetch (Bypasses Shared Host!)
            endpointUrl = apiBase + '/chat/completions';
            if (apiKey) reqHeaders['Authorization'] = 'Bearer ' + apiKey;
            reqBody = {
                model: model,
                messages: messagesPayload,
                stream: true,
                temperature: 0.7
            };
        } else {
            // Server Proxy Fetch
            endpointUrl = 'api.php?action=stream';
            reqBody = {
                model: model,
                messages: messagesPayload
            };
        }

        const res = await fetch(endpointUrl, {
            method: 'POST',
            headers: reqHeaders,
            body: JSON.stringify(reqBody)
        });

        if (!res.ok) {
            const errorText = await res.text();
            throw new Error('HTTP ' + res.status + ': ' + errorText.substring(0, 150));
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';
        streamTextContainer.innerHTML = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop();

            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed || trimmed === 'data: [DONE]') continue;

                if (trimmed.startsWith('data: ')) {
                    try {
                        const json = JSON.parse(trimmed.substring(6));
                        const delta = json.choices[0]?.delta || {};

                        // Handle reasoning tokens (DeepSeek-R1 / Gemini thinking)
                        if (delta.reasoning_content) {
                            reasoningText += delta.reasoning_content;
                        }

                        if (delta.content) {
                            let textChunk = delta.content;

                            if (textChunk.includes('<think>')) {
                                inThinkTag = true;
                                textChunk = textChunk.replace('<think>', '');
                            }
                            if (textChunk.includes('</think>')) {
                                inThinkTag = false;
                                textChunk = textChunk.replace('</think>', '');
                            }

                            if (inThinkTag) {
                                reasoningText += textChunk;
                            } else {
                                responseText += textChunk;
                            }
                        }

                        let finalHtml = '';
                        if (reasoningText) {
                            finalHtml += `
                                <details class="reasoning-box">
                                    <summary>🧠 Thought Process (${reasoningText.length} chars)</summary>
                                    <div class="reasoning-content">${escapeHtml(reasoningText)}</div>
                                </details>
                            `;
                        }
                        finalHtml += `<div>${formatMarkdown(responseText)}</div>`;
                        streamTextContainer.innerHTML = finalHtml;
                        messagesDiv.scrollTop = messagesDiv.scrollHeight;

                    } catch (e) {}
                }
            }
        }

        chatHistory.push({ role: 'assistant', content: responseText });
        const actionDiv = document.createElement('div');
        actionDiv.className = 'msg-actions';
        actionDiv.innerHTML = `
            <button class="btn btn-sm btn-primary" onclick="copyText(this)">📋 Copy Text</button>
            <button class="btn btn-sm btn-success" onclick="draftPost(this)">📝 Create Post Draft</button>
        `;
        aiBubble.appendChild(actionDiv);
        aiBubble.dataset.raw = responseText;

    } catch (err) {
        streamTextContainer.innerHTML = `<span style="color:#dc2626;"><strong>Connection Error:</strong> ${escapeHtml(err.message)}</span>`;
    }

    sendBtn.disabled = false;
    sendBtn.innerText = 'Send 🚀';
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function appendMessage(text, role) {
    const messagesDiv = document.getElementById('chatMessages');
    const msg = document.createElement('div');
    msg.className = `msg msg-${role}`;
    msg.innerHTML = escapeHtml(text).replace(/\n/g, '<br>');
    messagesDiv.appendChild(msg);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function formatMarkdown(text) {
    return escapeHtml(text)
        .replace(/\n\n/g, '<br><br>')
        .replace(/\n/g, '<br>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/`([^`]+)`/g, '<code style="background:#e2e8f0; padding:2px 4px; border-radius:3px;">$1</code>');
}

function copyText(btn) {
    const text = btn.closest('.msg-ai').dataset.raw;
    navigator.clipboard.writeText(text);
    btn.innerText = '✓ Copied!';
    setTimeout(() => btn.innerText = '📋 Copy Text', 2000);
}

function draftPost(btn) {
    const text = btn.closest('.msg-ai').dataset.raw;
    sessionStorage.setItem('ai_draft_content', text);
    window.open('<?php echo BASE_URL; ?>/admin/posts.php?action=create', '_blank');
}
</script>

<?php admin_footer(); ?>