<?php
// Register Admin Sidebar Item
add_action('admin_sidebar_menu', function($activePage) {
    $isActive = ($activePage === 'ai_workspace') ? 'active' : '';
    echo '<li class="' . $isActive . '"><a href="' . BASE_URL . '/plugins/ai-workspace/admin_page.php">🤖 AI Workspace</a></li>';
});